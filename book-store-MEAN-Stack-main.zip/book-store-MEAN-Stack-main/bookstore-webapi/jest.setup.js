// By default each test has a default timeout of 5 seconds
// After 5 seconds jest exits from the test

console.log('Running jest.setup.js')
jest.setTimeout(5 * 1000); // 5 seconds