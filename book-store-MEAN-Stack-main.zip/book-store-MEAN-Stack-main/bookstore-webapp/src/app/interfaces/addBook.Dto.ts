export interface IAddBookDto {

  language: string;

  author: string;

  title: string;

  dateOfPublish:string;

}
