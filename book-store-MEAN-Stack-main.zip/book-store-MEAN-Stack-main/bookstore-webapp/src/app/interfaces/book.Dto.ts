
export interface IBookDto {

  dateOfPublish: Date;

  language: string;

  author: string;

  title: string;

  _id: string;

}
